function openForm() {
    document.getElementById("recipeForm").style.visibility = "visible";
}

function closeForm() {
    document.getElementById("recipeForm").style.visibility = "hidden";
}