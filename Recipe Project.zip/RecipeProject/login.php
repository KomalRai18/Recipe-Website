<?php
include("connection/connect.php");
error_reporting(0);
session_start();
if(isset($_POST['submit']))
{
  include "config.php";
	$username = $_POST['user_name'];
	$password = $_POST['password'];
	
	if(!empty($_POST["submit"])) 
     {
	$loginquery ="SELECT * FROM signup WHERE email='$username' && password='$password' ";
	$result=mysqli_query($db, $loginquery);
	$row=mysqli_fetch_array($result);
	
  if(is_array($row))
		{
      $_SESSION["user_id"] = $row['user_id'];
			header("location:index.php");
	  } 
		else
		{
    $message = "Invalid Username or Password!";
    }
	 }
}





?>


<!DOCTYPE html>
<html>
  <head>
    <title>Admin Login</title>
    <!-- Bootstrap -->
    <link href="admin/bootstrap/css/bootstrap.min.css" rel="stylesheet" media="screen">
    <link href="admin/bootstrap/css/bootstrap-responsive.min.css" rel="stylesheet" media="screen">
    <link href="admin/assets/styles.css" rel="stylesheet" media="screen">
     <!-- HTML5 shim, for IE6-8 support of HTML5 elements -->
    <!--[if lt IE 9]>
      <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->
    <script src="admin/js/vendor/modernizr-2.6.2-respond-1.1.0.min.js"></script>
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
  </head>
  <body class="container-flex">
    <!-- <div id="login"> -->
      <div id="login">
        <img src="images\Epicurious-Id-portal-Image.webp" alt="">
      </div>
      <form class="form-signin" action='' method='post'>
          <div class="form">
          <h2 class="form-signin-heading">Sign in or Create an Account</h2>
          <div class="input-box">
            <input type="text" class="email" placeholder="Email Address"  name="user_name">
            <i class="ielement1"><img src="images\envelope-solid-36.png" alt=""></i>
          </div>
          <div class="input-box">
            <input type="password" class="password" placeholder="Password"  name="password">
            <i class="ielement2"><img src="images\lock-alt-solid-36.png" alt=""></i>
          </div>
          <label class="checkbox">
            <input type="checkbox" value="remember-me"> Remember me
          </label>
          
          <input name='submit' class="btn btn-large btn-primary" type="submit" value='Login'>
          <center ><?php echo  '<div style="color:red;"> '.$message.'</div>';?></center>
          <div class="register"><p>Don't have an Account?</p><a href="signup.php">Register</a></div>
        </div>
        </form>
    <!-- </div> -->
    <script src="vendors/jquery-1.9.1.min.js"></script>
    <script src="bootstrap/js/bootstrap.min.js"></script>
  </body>
</html>