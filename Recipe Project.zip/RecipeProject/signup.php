<?php
include("connection/connect.php");
  
if(isset($_POST['submit']))
{
	if(empty($_POST['username'])){
		echo 'Name is Required' . "<br>";
	}
	else if(empty($_POST['email'])){
		echo 'Email is Required' . "<br>";
	}
	else if(empty($_POST['password'])){
		echo 'Password is Required'.'<br>';
	}

	$username = $_POST['username'];
	$email=$_POST['email'];	
	$password=$_POST['password'];

	$sql = "INSERT INTO signup(firstname,lastname,email,password) VALUES('$fname','$lname','$email','$password')";
	 $query=mysqli_query($db, $sql);
	if($query)
	{
		header('location:signup_success.php');
	}
	
	

}
 

?>

<!DOCTYPE html>
<!-- Website template by freewebsitetemplates.com -->
<html>
<head>
	<meta charset="UTF-8">
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
	<title>signup</title>
	<link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>
	<div class="header">
		<div class="logo">
			<a href="index.php"><img src="images/logo1.png" alt="Logo"></a>
		</div>
		<nav class="navbar">
			<ul>
					<li>
						<a href="index.php">Home</a>
					</li>
					<li>
						<a href="recipes.php">Recipes</a>
					</li>
					<li>
						<a href="featured.php">Recipe of Month</a>
					</li>
					
					<li class="">
						<a href="about.php">About</a>
					</li>
			</ul>
		</nav>
		<div class="tiles">
			<div class="login">

				<a href="login.php">Login</a>
			</div>
			<div class="signup">

				<a href="signup.php">SignUp</a>
			</div>
		</div>
	</div>
	<div class="body">

				<div id="content">
					<div>
							<center><h3>Sign up</h3></center>
					    <form action='' method='post'>
					    	<div class="input">
						    	<label for="username">UserName</label>
								<input type="text" name="username" id="username" required class="form-input" style="padding: 5px 5px; width: 450px; margin-left: 50px">
								<i class="ielement1"><img src="images\user-solid-36.png" alt=""></i>
						    </div>
							<div class="input">
								
						    	<label for="email">Email Address</label>
								<input type="text" name="email" id="email" required class="form-input" style="padding: 5px 5px; width: 450px; margin-left: 27px">
								<i class="ielement2"><img src="images\envelope-solid-36.png" alt=""></i>
						    </div>
							<div class="input">
								<label for="password">Password</label>
								<input type="password" id="password" name="password" aria-describedby="passwordHelpInline" class="form-input" style="padding: 5px 5px; width: 450px; margin-left: 50px">
								<i class="ielement3"><img src="images\lock-alt-solid-36.png" alt=""></i>
								<small style="margin-left: 120px;">Must be 8-20 characters long.</small>
							</div>
						   <div>
						   		<span><input type="submit" name='submit' value="Sign Up" class="signup" style="background-color: #2ca82c; border: none; border-radius: 119px; width: 113px; padding: 14px 0px; color: #fff; font-size: 21px;"></span>
						  	</div>
							<div class="login-link" style="display: flex; justify-content: center">
								<p>Already a member?</p>
								<a href="login.php" style="text-decoration: none; margin-top: 10px; color: black; font-weight: bold; font-size: 16px; letter-spacing: 0.04rem; margin-left: 5px;">Sign in</a>
							</div>
					    </form>
						
					</div>
				</div>
				<div class="videos">
			<div>
				<h3>Cooking Video</h3>
				<a href="videos.html"><img src="images/cooking-video.png" alt="Image"></a>
				<span>Vegetable &amp; Rice Topping</span>
			</div>
			<div class="featured-recipes">
				<h3>Featured Recipes</h3>
				<ul id="featured">
					<li>
						<a href="recipes.html"><img src="images/sandwich.jpg" alt="Image"></a>
						<div>
							<h2><a href="recipes.html">Ham Sandwich</a></h2>
							<span>by: Anna</span>
						</div>
					</li>
					<li>
						<a href="recipes.html"><img src="images/biscuit-and-coffee.jpg" alt="Image"></a>
						<div>
							<h2><a href="recipes.html">Biscuit &amp; Sandwich</a></h2>
							<span>by: Sarah</span>
						</div>
					</li>
					<li>
						<a href="recipes.html"><img src="images/pizza.jpg" alt="Image"></a>
						<div>
							<h2><a href="recipes.html">Delicious Pizza</a></h2>
							<span>by: Rico</span>
						</div>
					</li>
				</ul>
			</div>
			<div class="blog">
				<h3>Blog</h3>
				<ul id="blog">
					<li>
						<a href="blog.html">This is just a place holder, so you can see what the site would look like.</a>
						<span class="date">Jan 9, by Liza</span>
					</li>
					<li>
						<a href="blog.html">This is just a place holder, so you can see what the site would look like.</a>
						<span class="date">Feb 16, by Myk</span>
					</li>
					<li>
						<a href="blog.html">This is just a place holder, so you can see what the site would look like.</a>
						<span class="date">March 15, by Xaxan</span>
					</li>
				</ul>
			</div>
			<div class="updates">
				<h3>Get Updates</h3>
				<a href="http://freewebsitetemplates.com/go/facebook/" target="_blank" id="facebook">Facebook</a>
				<a href="http://freewebsitetemplates.com/go/twitter/" target="_blank" id="twitter">Twitter</a>
				<a href="http://freewebsitetemplates.com/go/youtube/" target="_blank" id="youtube">Youtube</a>
				<a href="http://freewebsitetemplates.com/go/flickr/" target="_blank" id="flickr">Flickr</a>
				<a href="http://freewebsitetemplates.com/go/googleplus/" target="_blank" id="googleplus">Google&#43;</a>
			</div>
		</div>
	</div>
	<div class="footer">
		<div>
			<p>
				&copy;(Navbro) Copyright 2012. All rights reserved
			</p>
		</div>
	</div>
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
</body>
</html>