<?php
include('connection/connect.php');

session_start(); //session started by unique user_id
  
error_reporting(0);                                                                      //for printing the  text
  $sql = "SELECT * FROM signup where user_id='".$_SESSION["user_id"]."'";
  $result = mysqli_query($db, $sql);
  $row = mysqli_fetch_array($result);
  $name=$row['firstname'];

  if($_SESSION["user_id"]==0)
  {
	  $none='none';
  }
  if (isset($_POST['submit'])) {
    // Sanitize and escape user inputs to prevent SQL injection
    $recipeName = mysqli_real_escape_string($db, $_POST['recipeName']);
    $recipeInstructions = mysqli_real_escape_string($db, $_POST['recipeInstructions']);

    // File Upload
	$file_name = $_FILES['file']['name'];
	$temp_file = $_FILES['file']['tmp_name'];
	$file_size = $_FILES['file']['size'];

	$file_new_name = uniqid() . '_' . $file_name;

	$upload_directory = "img/" . basename($file_new_name);
	move_uploaded_file($temp, $store);
	if($recipeName== '' || $recipeInstructions=='' || $file_new_name==''){
		$message = '<div class="alert alert-error alert-block">
					<a class="close" data-dismiss="alert" href="#">&times;</a>
					<h4 class="alert-heading">Error!</h4>
					Error occured while adding the recipe.
				</div>';}
	else {

	$sql = "INSERT INTO recipes(rimage, resname, rtext) VALUES ('$file_new_name', '$recipeName', '$recipeInstructions')";
	mysqli_query($db, $sql);

	$message = '<div class="alert alert-success">
					<button type="button" class="close" data-dismiss="alert">&times;</button>
					<h4>Success</h4>
					Recipe added successfully
				</div>';
    } 
    	
}
if (isset($_POST['logout'])) {
    // Unset all of the session variables
    $_SESSION = array();

	session_unset();
    // Destroy the session
    session_destroy();

    // Redirect to the login page or any other desired page after logout
    header("Location: logins.php"); // Change 'login.php' to the desired page
    exit;
} 

?>

<!DOCTYPE html>
<!-- Website template by freewebsitetemplates.com -->
<html>
<head>
	<meta charset="UTF-8">
	<title>Food &amp; Recipes Web Template</title>
	<link rel="stylesheet" type="text/css" href="css/style.css">
<link href="rating.css" rel="stylesheet" type="text/css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<script type="text/javascript" src="rating.js"></script>
<script language="javascript" type="text/javascript">
$(function() {
    $("#rating_star").codexworld_rating_widget({
        starLength: '5',
        initialValue: '',
        callbackFunctionName: 'processRating',
        imageDirectory: 'images/',
        inputAttr: 'postID'
    });
});

function processRating(val, attrVal){
    $.ajax({
        type: 'POST',
        url: 'rating.php',
        data: 'postID='+attrVal+'&ratingPoints='+val,
        dataType: 'json',
        success : function(data) {
            if (data.status == 'ok') {
                alert('You have rated '+val+' to CodexWorld');
                $('#avgrat').text(data.average_rating);
                $('#totalrat').text(data.rating_number);
            }else{
                alert('Some problem occured, please try again.');
            }
        }
    });
}
</script>
<style type="text/css">
    .overall-rating{font-size: 14px;margin-top: 5px;color: #8e8d8d;}
</style>
</head>
<body>
	<div class="header">
		<div class="logo">
			<a href="index.php"><img src="images/logo1.png" alt="Logo"></a>
		</div>
		<nav class="navbar">
			<ul>
					<li class="current">
						<a href="index.php">Home</a>
					</li>
					<li>
						<a href="recipes.php">Recipes</a>
					</li>
					<li>
						<a href="featured.php">Recipe of Month</a>
					</li>
					
					<li class="">
						<a href="about.php">About</a>
					</li>
			</ul>
		</nav>
		<div class="tiles">
		<?php
			if(empty($_SESSION["user_id"]))
				{
				echo '<div class="login"><a href="login.php">Login</a></div>';
				echo '<div class="signup"><a href="signup.php">SignUp</a></div>';
				}
			else
				{
				$logout= '<form action="login.php" method="post" >
				<input type="submit" class="logout" name="logout" value = "Logout"></form>
				<button class="add-recipe-btn" onclick="openForm()">Add Recipe</button>';
				echo $logout;
				}

		?>
		</div>
	</div>
	<div class="form-popup" id="recipeForm">
    <form action="" method="post" class="form-container">
        <h2>Add Recipe</h2>

        <label for="recipeName"><b>Recipe Name</b></label>
        <input type="text" placeholder="Enter Recipe Name" name="recipeName" required>

        <label for="recipeInstructions"><b>Recipe Instructions</b></label>
        <textarea placeholder="Enter Recipe Instructions" name="recipeInstructions" rows="4" required></textarea>
		
		<label class="control-label" for="fileInput" >File input</label>
		<input class="input-file uniform_on" id="fileInput" type="file"  name="file" style="margin-top: 5px;">
		
		<div>
		<button type="submit" class="btn" name="submit" style="display: inline-block; background-color: forestgreen; padding: 14px; border: none; border-radius: 3px; margin-top: 40px; font-size: 15px; color: antiquewhite; letter-spacing: 1px; margin-right: 5px">Publish Recipe</button>
        <button type="button" class="btn cancel" onclick="closeForm()" style="color: black; border-radius: 4px; width: 80px; border: none; padding: 14px; background-color: beige; font-size: 15px; letter-spacing: 1px;">Close</button>
		</div>
    </form>
	</div>
	<div  style="background-color:;margin:auto;min-height:20px;display:<?php echo $none;?>;">
	<div  style="background-color:;margin-left:200px;width:950px;min-height:30px;">
	<p style='float:left;color:#449c3a;margin-left:10px;font-size:20px;'>You successfully login!</p>
		<p style='float:right;color:#fff;margin-left:px;font-size:20px;'>Welcome:<span style='margin-right:0px;display:inline-block;margin-right:5px;'><?php echo $name ?></span>
			<image src='images/user.png'  style='display:inline-block;height:20px;width:20px;margin-top:5px;margin-right:5px;'/>
	</div>	
	</div>
	<div class="body">
		<div>
			<div class="body">
				<div>
					<!-- <a href="index.php"><img src="images/turkey.jpg" alt="Image"></a> -->
					<div class="turkey-background">
						<form action="search.php" method="post">
							<input type="search" value="" placeholder="Search your recipe" class="search" name='search'>
						</form>
					</div>
				</div>
				<ul>
					<li class="current">
						<a href="blog.php"><img src="images/holi-turkey.jpg" alt="Image"></a>
						<div>
							<h2><a href="blog.php">Holy Turkey</a></h2>
							<p>
								Tuck wings under turkey
								
							</p>
						</div>
					</li>
					<li>
						<a href="blog.php"><img src="images/fruits-and-bread.jpg" alt="Image"></a>
						<div>
							<h2><a href="blog.php">Fruits &amp; Bread</a></h2>
							<p>
								Fresh Fruit Bread Recipe
							</p>
						</div>
					</li>
					<li>
						<a href="blog.php"><img src="images/dessert.jpg" alt="Image"></a>
						<div>
							<h2><a href="blog.php">Dessert</a></h2>
							<p>
								5 Quick-and-Easy Dessert Recipes
							</p>
						</div>
					</li>
				</ul>
			</div>
			<div class="footer">
				<ul>
				<li>
						<h2><a href="recipes.php"> Recipes</a></h2>
						<a href="recipes.php"><img src="images/a-z.jpg" alt="Image"></a>
					</li>
					<li>
						<h2><a href="featured.php">Featured Recipes</a></h2>
						<a href="featured.php"><img src="images/featured.jpg" alt="Image"></a>
					</li>
					
				</ul>
				<ul>
					<li>
						<h2><a href="videos.php">Videos</a></h2>
						<a href="videos.php"><img src="images/videos.jpg" alt="Image"></a>
					</li>
					<li>
						<h2><a href="blog.php">Blog</a></h2>
						<a href="blog.php"><img src="images/blog.jpg" alt="Image"></a>
					</li>
				</ul>
			</div>
		</div>
		<div>
			<div>
				<h3>Cooking Video</h3>
				<a href="videos.html"><img src="images/cooking-video.png" alt="Image"></a>
				<span>Vegetable &amp; Rice Topping</span>
			</div>
			<div class="featured-recipes">
				<h3>Featured Recipes</h3>
				<ul id="featured">
					<li>
						<a href="recipes.html"><img src="images/sandwich.jpg" alt="Image"></a>
						<div>
							<h2><a href="recipes.html">Ham Sandwich</a></h2>
							<span>by: Anna</span>
						</div>
					</li>
					<li>
						<a href="recipes.html"><img src="images/biscuit-and-coffee.jpg" alt="Image"></a>
						<div>
							<h2><a href="recipes.html">Biscuit &amp; Sandwich</a></h2>
							<span>by: Sarah</span>
						</div>
					</li>
					<li>
						<a href="recipes.html"><img src="images/pizza.jpg" alt="Image"></a>
						<div>
							<h2><a href="recipes.html">Delicious Pizza</a></h2>
							<span>by: Rico</span>
						</div>
					</li>
				</ul>
			</div>
			<div class="blog">
				<h3>Blog</h3>
				<ul id="blog">
					<li>
						<a href="blog.html">This is just a place holder, so you can see what the site would look like.</a>
						<span class="date">Jan 9, by Liza</span>
					</li>
					<li>
						<a href="blog.html">This is just a place holder, so you can see what the site would look like.</a>
						<span class="date">Feb 16, by Myk</span>
					</li>
					<li>
						<a href="blog.html">This is just a place holder, so you can see what the site would look like.</a>
						<span class="date">March 15, by Xaxan</span>
					</li>
				</ul>
			</div>
			<div class="updates">
				<h3>Get Updates</h3>
				<a href="http://freewebsitetemplates.com/go/facebook/" target="_blank" id="facebook">Facebook</a>
				<a href="http://freewebsitetemplates.com/go/twitter/" target="_blank" id="twitter">Twitter</a>
				<a href="http://freewebsitetemplates.com/go/youtube/" target="_blank" id="youtube">Youtube</a>
				<a href="http://freewebsitetemplates.com/go/flickr/" target="_blank" id="flickr">Flickr</a>
				<a href="http://freewebsitetemplates.com/go/googleplus/" target="_blank" id="googleplus">Google&#43;</a>
			</div>
		</div>
	</div>
	<div class="footer">
		<div>
			<p>
				&copy;(Navbro) Copyright 2012. All rights reserved
			</p>
		</div>
	</div>
	<script src="addrecipe.js"></script>
</body>
</html>