<?php

    $employee = array(
        "komal"=>"Software Engineer",
        "sandhiya"=>"CA",
        "muskan" =>"Doctor",
    );
    $ekeys = array_keys($employee);
    $evalue = array_values($employee);
    $employee = array_flip($employee);
    echo "<pre>";
    // print_r($evalue);
    // print_r($ekeys);
    print_r($employee);
    ?>
<?php

    foreach($employee as $key => $value) {
        ?>    
        <p><b><?php echo ucwords($key)?>:</b> <?php echo $value?></p>

<?php }?>